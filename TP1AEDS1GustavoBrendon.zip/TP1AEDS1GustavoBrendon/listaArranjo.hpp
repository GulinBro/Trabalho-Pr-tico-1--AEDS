#ifndef LISTA_A_H
#define LISTA_A_H
#include <iostream>

using namespace std;

#define MAXTAM 5

typedef int TipoApontador;

typedef struct Projeto
{
    int chave;
    char nome[50];
    int horas;
};

typedef struct ListaProjetos
{
    Projeto Item[MAXTAM];
    int Primeiro, Ultimo;
    int tamanho;
};

bool listaCriadaArranjo = false;


//Cria uma lista vazia.
void criaListaVazia(ListaProjetos *lista);
//Verifica e retorna TRUE se a lista estiver vazia e FALSE se não estiver.
int verificaListaVazia(ListaProjetos *lista);   
//Verifica e retorna TRUE se a lista estiver cheia e FALSE se não estiver.                        
int verificaListaCheia(ListaProjetos *lista);   
//Insere um ITEM na lista, (ListaProjetos).
int insereItem(ListaProjetos *lista, Projeto item);    
//Imprime a lista.              
void imprimeLista(ListaProjetos lista);
//Pesquisa um ITEM na lista, (ListaProjetos).                                 
int pesquisaItem(ListaProjetos *lista, int chave);
//Remove um item da lista pela posição ocupada.                     
void retiraItem(TipoApontador p, ListaProjetos *lista);
//Retorna o número de itens da lista. 
int tamanhoLista(ListaProjetos *lista);                                 

#endif