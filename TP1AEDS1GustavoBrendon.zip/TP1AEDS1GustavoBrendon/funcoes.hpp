#ifndef FUNCOES_H
#define FUNCOES_H

#include "listaEncadeada.hpp"

void menu();

void recuperaLista(ListaFuncionario *lista);

void salvaLista(ListaFuncionario *lista);

void desalocaLista(ListaFuncionario *lista);


#endif